<?php $__env->startSection('content'); ?>
<div class="container">
<div class="confirm-container">
<form action="" type="GET">
    <div id="display-msg" class="alert alert-success">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione, eligendi!</p>
    </div>
    <div class="form-group">
        <h3 for="">input confirmation code below</h3>
        <input type="text" name="confirm" placeholder="input code" class="form-control mb-3 input-medium">
<button class="btn btn-danger btn-lg">Confrim</button>
    </div>
</div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/layouts/confirm.blade.php ENDPATH**/ ?>