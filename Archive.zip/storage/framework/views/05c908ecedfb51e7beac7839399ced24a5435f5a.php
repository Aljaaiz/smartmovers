<?php $__env->startSection('content'); ?>
<div class="container my-5">
<h3 class="m-3 text-center text-white">Details Confirmation Page</h3>
<table class="table table-bordered text-center bg-light">
<thead>
<tr>
<th>Ccode</th>
<th>Name</th>
<th>Apratment/Office No</th>
<th>Items to Move</th>

<th>Email</th>
<th>Phone No.</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>

<tr>
   <td><?php echo e($singleMover->ccode); ?></td>
   <td><?php echo e($singleMover->name); ?></td>
   <td><?php echo e($singleMover->apartmentNo); ?></td>
   <td><?php echo e($singleMover->movingItems); ?></td>
   <td><?php echo e($singleMover->email); ?></td>
   <td><?php echo e($singleMover->pnumber); ?></td>
   <td><?php echo e($singleMover->permissionStatus); ?></td>
   <td>
<form action="/update/{id}/{statusValue}" method="POST">
<?php echo csrf_field(); ?>
<select name="status" class="status" id="<?php echo e($singleMover->id); ?>">
<option value="">---Choose---</option>
<option value="Approved">Approved</option>
<option value="Not Approved">Not Approved</option>
<option value="Check with Office">Check with Office</option>
</select>
</form>
</td> 
</tr>

</div>
<?php $__env->stopSection(); ?>
<script
  src="https://code.jquery.com/jquery-3.6.0.js"
  integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
  crossorigin="anonymous"></script>
  <script>


    // $(document).ready(function(){
    //    $('#changestatus').on('change',function(){
    //         let selectVal  = $('#changestatus').val()
    //         console.log(selectVal);

    //       $.ajax({
    //           method:'POST',
    //           url:"/update",
    //       dataType:'json',
    //       data:{
    //         _token:'<?php echo e(csrf_token()); ?>',
    //          'selectVal': selectVal,
    //          },
    //           success:function(res){
    //           console.log(res);
    //           }
    //         })
    //     })
    // })
  //Change student Status
$(document).ready(function(){

$('.status').change(function () {
    var statusValue = $('.status').val()
    let id = $('.status').attr('id');
    console.log(id,statusValue)


    $.ajax({
      url: '/update/' + id + '/' + statusValue,
      type: 'POST',
      datatype: 'json',
      data: JSON.stringify({
        _token:'<?php echo e(csrf_token()); ?>',
        'id': id,
        'statusValue': statusValue,
        
      }),
      contentType: 'application/json ,charset=UTF-8',
      success: function (data) {
        console.log(data)
        location.reload(true);
      },
      error: function (err) {
        console.log(err)
      }

    })

  })

})
</script>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/layouts/details.blade.php ENDPATH**/ ?>