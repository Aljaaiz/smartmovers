<?php $__env->startSection('content'); ?>
    <div class="col-md-6 my-4 p-4 mx-auto bg-dark   justify-content-center align-items-center">
        <h1 class="text-white text-center">Check Status</h1>
        <div class="row">
            <div class="col-md-12">
                <form action="/statusq/{ccode}" method="GET" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php $__errorArgs = ['ccode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <h4 class="text-danger text-center">
                            <?php echo e($message); ?>

                        </h4>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="ccode" class="form-control btn-lg mb-3"
                        placeholder="Input your application code">
                    <button type="submit" class="btn btn-primary d-grid gap-2 col-6 mx-auto mb-4 py-2">Search</button>
                </form>
                <?php if(!empty($singleMover)): ?>
                    <div class="card col-sm-12">
                        <div class="card-body">
                            <?php
                                $status = $singleMover->permissionStatus;
                                switch ($status) {
                                    case 'Approved':
                                        echo "<h3 class='alert alert-success text-center'>$singleMover->permissionStatus</h3>";
                                        break;
                                    case 'Check with Office':
                                        echo "<h3 class='alert alert-warning text-center'>$singleMover->permissionStatus</h3>";
                                        break;
                                
                                    case 'Not Allow':
                                        echo "<h3 class='alert alert-danger text-center'>$singleMover->permissionStatus</h3>";
                                        break;
                                    case 'Pending':
                                        echo "<h3 class='alert alert-info text-center'>$singleMover->permissionStatus</h3>";
                                        break;
                                }
                                
                                // if($singleMover->permissionStatus == 'approved'){
                                //  <h3 class="alert alert-{{ $color = 'success' }} text-center">{{ $singleMover->permissionStatus }}</h3>
                                // }
                                
                            ?>
                            <ul class="list-group text-center">
                                <li class="list-group-item">
                                    <h5 class="d-inline-block text-muted">Items to Move: </h5>
                                    <h4><?php echo e($singleMover->movingItems); ?></h4>
                                </li>

                                <li class="list-group-item">
                                    <h5 class="d-inline-block text-muted">Apartment/Office: </h5>
                                    <h4 class="text-bold"><?php echo e($singleMover->apartmentNo); ?></h4>
                                </li>
                                <li class="list-group-item">
                                    <h5 class="d-inline-block text-muted">Moving Type : </h5>
                                    <h4><?php echo e($singleMover->movingtype); ?></h4>
                                </li>
                                <li class="list-group-item">
                                    <h5 class="d-inline-block text-muted">Movers Company : </h5>
                                    <h4><?php echo e($singleMover->moverscompany); ?></h4>
                                </li>
                                <li class="list-group-item">
                                    <h5 class="d-inline-block text-muted">Moving Date : </h5>
                                    <h4><?php echo e($singleMover->date_time); ?></h4>
                                </li>

                                
                            </ul>
                            
                            <h4 class="my-3 text-muted text-center fw-bolder">Updated_by: <?php echo e($singleMover->usr_name); ?>

                            </h4>

                        <?php else: ?>
                            
                            <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endif; ?>
            </div>
        </div>


    </div>
    </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/movers/movers/resources/views/layouts/status.blade.php ENDPATH**/ ?>