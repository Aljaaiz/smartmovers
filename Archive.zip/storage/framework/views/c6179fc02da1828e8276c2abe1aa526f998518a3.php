<div class="container">
  <div class="main-div d-flex just-content-center flex-column align-items-center" id="home-container">
    <h1 class="welnote">Welcome to 48burgate <br />Movers portals</h1>
    <?php if(session('msg')): ?>
    <h4 class="alert alert-success">
      <p><?php echo e(session('msg')); ?></p>
    </h4>
    <?php endif; ?>
    <p>Moving your Items made easy</p>
    
    <a class="btn btn-danger btn-lg" href="<?php echo e(route('create')); ?>">Continue</a>
  </div>
</div>
</body>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/index.blade.php ENDPATH**/ ?>