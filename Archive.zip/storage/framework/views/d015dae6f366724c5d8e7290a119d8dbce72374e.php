<?php $__env->startSection('content'); ?>

<?php if(session('ccode')): ?>
   <div id="msg_box" class="py-4" style="display:flex;justify-content:center;align-items:center;flex-direction:column;margin:200px auto;background:#000;max-width:450px;color:#fff;border-radius:5px">
    <h3 class="text-success fw-bolder">Thank you</h3>
    <p class="fw-light text-wrap text-center px-2">Your request has been submitted succesfully Check with your confirmation code below for follow up</p>
    <p style="fw-bolder font-size:1.2rem">Tracking Code:</p>
    <h3 style="font-size:2rem;letter-spacing:4px" class="fw-bold"><?php echo e(session('ccode')); ?></h3>
   
   
   </div> 
 <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/movers/movers/resources/views/layouts/thankyou.blade.php ENDPATH**/ ?>