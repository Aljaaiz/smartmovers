<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;800&display=swap" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/main.css">
    <title>Smart Movers</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="/">movers</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href=<?php echo e(url('/')); ?>>Home</a>
                    </li>

                    <li class="nav-item ml-right">
                        <a class="nav-link" href="<?php echo e(route('status')); ?>">Track</a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <footer class="footer bg-dark text-white">
        <div id="footer" class="text-center">
            <p>All rights reserved &copy; <span id="year"></span></p>
        </div>
        </div>
    </footer> --}}
    
    <script>
        let today = new Date()
        let y = today.getFullYear()
        document.getElementById('year').textContent = y;
    </script>
</body>

</html>
<?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/movers/movers/resources/views/layouts/base.blade.php ENDPATH**/ ?>