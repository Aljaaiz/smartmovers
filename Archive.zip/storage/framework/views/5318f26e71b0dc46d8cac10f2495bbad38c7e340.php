<?php $__env->startSection('content'); ?>

<?php if(session('ccode')): ?>
   <div id="msg_box" class="py-4" style="display:flex;justify-content:center;align-items:center;flex-direction:column;margin:200px auto;background:#000;max-width:450px;color:#fff;border-radius:5px">
    <h4 class="text-success">Thank you</h4>
    <p class="text-bold">Your request has been submitted succesfully</p>
    <p class="px-4">Check with your confirmation code below for follow up</p>
    <p style="font-size:1.2rem">Tracking Code:</p>
    <h3 style="font-size:2rem"><?php echo e(session('ccode')); ?></h3>
   
   
   </div> 
 <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/layouts/thankyou.blade.php ENDPATH**/ ?>