<?php $__env->startSection('content'); ?>
<div class="container">

<div class="col-md-10 mx-auto sm-12  bg-inverse">
<div class="form-div">
  <h3 class="text-center">Please fill in the field below for your moving request</h3>
<div class="row d-flex justify-content-center align-items-center">
<div class="col-md-6 py-4 justify-content-center align-items-center">

    <form action="<?php echo e(route('store')); ?>" method="POST">
  
<?php echo csrf_field(); ?>

<div class="col">
    <div class="form-group mb-3">
      <label for="name">Name</label>
      <input type="text" name="name" class="form-control shadow-none" value="<?php echo e(old('name')); ?>">
<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger">
       <?php echo e($message); ?>

    </p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-md-12 col-sm-12">
    <div class="form-group mb-3">
      <label for="name">Phone number</label>
      <input type="number" name="pnumber" class="form-control shadow-none" value="<?php echo e(old('pnumber')); ?>">
    <?php $__errorArgs = ['pnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-danger">
        <?php echo e($message); ?>

        </p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col">
<div id="picker"> </div>
<input type="hidden" id="result" value="">
</div>
<div class="col">
    <div class="form-group mb-3">
      <label for="name">Email</label>
      <input type="email" name="email" class="form-control shadow-none" value="<?php echo e(old('email')); ?>">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger">
            <?php echo e($message); ?>

            </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col">
    <div class="form-group mb-3">
<label for="" class="d-block">Commercial/Apartment</label>
    <select name="apttype" id="aptType" class="form-control shadow-none">
        <option value="office" >office</option>
        <option value="apartment">residence</option>
    </select>
</div>
</div>
<div class="col">
    <div class="form-group mb-3">
<label for="">Office/Apartemt no.</label>
   <input type="number" name="apartmentNo" class="form-control" value="<?php echo e(old('apartmentNo')); ?>">
<?php $__errorArgs = ['apartmentNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger">
       <?php echo e($message); ?>

    </p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>

<div class="col">
    <div class="form-group mb-3">
    <label for="">Moving Type</label>
    <select  name="movingtype" class="mb-2 form-control shadow-none">
        <option value="move-in">move-in</option>
        <option value="move-out">move-out</option>
        <option value="Delivery">Delivery</option>
    </select>
</div>
</div>
<div class="col">
    <div class="form-group mb-3">
    <label for="">Date and Time</label>
    <input class="form-control shadow-none" rows="2" name="date" id="move_at">
<?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger">
       <?php echo e($message); ?>

    </p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<div class="col">
    <div class="form-group mb-3">
    <label for="">Movers Company</label>
    <textarea class="form-control shadow-none" rows="2" name="moverscompany"></textarea>
<?php $__errorArgs = ['moverscompany'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger">
       <?php echo e($message); ?>

    </p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<div class="col">
    <div class="form-group mb-3">
    <label for="">Items to be moved</label>
    <textarea class="form-control shadow-none" rows="4" name="movingItems" placeholder="Items to be moved"> </textarea>
<?php $__errorArgs = ['movingItems'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-danger">
       <?php echo e($message); ?>

    </p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
      <div class="d-grid">
        <button type="submit" class="btn  btn-info btn-block py-3 text-white">Submit</button>
</div>
        </form>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>flatpickr('#move_at',{
enableTime:true
})</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css"> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/movers/movers/resources/views/layouts/create.blade.php ENDPATH**/ ?>