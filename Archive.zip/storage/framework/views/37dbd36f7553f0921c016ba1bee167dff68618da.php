


    



   


<?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/layouts/base.blade.php ENDPATH**/ ?>