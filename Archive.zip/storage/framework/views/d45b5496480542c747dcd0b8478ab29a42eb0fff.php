<?php $__env->startSection('content'); ?>


<div class="container" id="dashboard-header">
<h2 class="text-center py-3">DASHBOARD</h2>
<div class="bg-light my-3 p-3 d-flex justify-content-center">
  <form action="" method="GET">
    <?php echo csrf_field(); ?>
    <input type="text" name="input ccode">
    <button class="btn  btn-info">Search</button>
</form>
</div>
</div>
 <div class="container">
<div class="">
<table class="table table-bordered text-center my-5 py-5 bg-light" id="table">
<thead class="table-dark fw-bold">
<tr>
<th class="fw-bold">SN</th>
<th>Name</th>
<th>Floor No</th>
<th>Items to Move</th>
<th>Moving Type</th>
<th>Date and Time</th>
<th>Movers Company</th>
<th>Email</th>
<th>Phone No.</th>
<th>Date Submitted</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<?php $__currentLoopData = $movers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mover): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tbody>
<tr>
 <td><?php echo e($mover['id']); ?></td>
   <td><?php echo e($mover['name']); ?></td>
   <td><?php echo e($mover['apartmentNo']); ?></td>
   <td><?php echo e($mover['movingItems']); ?></td>
   <td><?php echo e($mover['movingtype']); ?></td>
   <td><?php echo e($mover['date_time']); ?></td>
   <td><?php echo e($mover['moverscompany']); ?></td>
   <td><?php echo e($mover['email']); ?></td>
   <td><?php echo e($mover['pnumber']); ?></td>
   <td><?php echo e($mover['created_at']); ?></td>
   <td><?php echo e($mover['permissionStatus']); ?></td>
   <td><a  class="action" href="/details/<?php echo e($mover['ccode']); ?>">Action</a></td>
</tr>
</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($movers->links()); ?>

</div>
 </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/movers/movers/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>