<?php $__env->startSection('content'); ?>
<div class=" col-md-6 my-4 py-4 mx-auto bg-dark d-flex flex-column  justify-content-center align-items-center">
<h1>Check Status</h1>
<div class="row">
<div class="col-md-12">
<form action="/statusq/{ccode}" method="GET" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php $__errorArgs = ['ccode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger">
            <?php echo e($message); ?>

            </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text" name="ccode" class="form-control btn-lg mb-3" placeholder="Input your application code">
        <button type="submit" class="btn btn-primary d-grid gap-2 col-6 mx-auto">Search</button>
</form>
        <?php if(!empty($singleMover )): ?>
        <div class="card col-sm-12">
            <div class="card-body">
            <h3 class="alert alert-info text-center"><?php echo e($singleMover->permissionStatus); ?></h3>
        <ul class="list-group text-center">


            <li class="list-group-item"><h5 class="d-inline-block text-muted">Items to Move: </h5><h4><?php echo e($singleMover->movingItems); ?></h4></li>

            <li class="list-group-item"><h5 class="d-inline-block text-muted">Apartment/Office: </h5> <h4 class="text-bold"><?php echo e($singleMover->apartmentNo); ?></h4></li>


            <li class="list-group-item"><h5 class="d-inline-block text-muted">Moving Type : </h5><h4><?php echo e($singleMover->movingtype); ?></h4></li>

            
        </ul>
                <h5 class="my-3">Signed by: </h5>
                <h6 class="my-3"><?php echo e($singleMover->updated_at); ?></h6>
        <?php else: ?>
            
            
        </div>
        </div>
  <?php endif; ?>
</div>
</div>    

</div>
<?php $__env->stopSection(); ?>
<script
  src="https://code.jquery.com/jquery-3.6.0.js"
  integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
  crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
//   alert('.');
})
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/layouts/status.blade.php ENDPATH**/ ?>