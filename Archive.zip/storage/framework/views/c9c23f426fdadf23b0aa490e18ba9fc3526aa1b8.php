<?php $__env->startSection('content'); ?>
        <div class="col-md-5 mx-auto">
        <div class="container mt-5">
        <div class="card py-5">
        <div class="card-body text-center">
        <h3>Login</h3>
            <form autocomplete="off" action="" method="GET">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control mb-3" name="email" placeholder="Enter email" autocomplete="off">
                <input type="text" class="form-control mb-3" name="email" placeholder="password">
        <button type="submit" class="btn btn-info text-center px-5">Login</button>
</form>
</div>
</div>
</div>
</div>
<?php echo csrf_field(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/layouts/login.blade.php ENDPATH**/ ?>