<?php $__env->startSection('content'); ?>
<div class="container">
<div class="confim-container">
<form action="<?php echo e(route('confirm/{code}')); ?>" type="GET">
    <div class="form-group">
        <label for="">input confirmation code below</label>
        <input type="text" name="confirm" placeholder="input code">
<div class="btn btn-danger">Confrim</div>
    </div>
</div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jamiu/Documents/Project/PHP PROJECTS/Tanmeya movers/movers/resources/views/layouts/confirmpage.blade.php ENDPATH**/ ?>